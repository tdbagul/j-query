# WT-Assignment-3 : Menu-Description
- Drop-down list of Resturant Menus by fetching the data from a JSON file stored on a server machine to show details of given menu.
